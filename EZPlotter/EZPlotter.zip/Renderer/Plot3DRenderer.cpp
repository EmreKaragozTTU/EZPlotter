
#include "Plot3DRenderer.h"

const char* PLOT3D_VS_HLSL =
"struct VS_OUTPUT"
"{"
"	float4 Position : SV_POSITION;"
"	float3 WorldPosition : TEXCOORD;"
"};"
""
"cbuffer PER_PLOT : register(b0)"
"{"
"	float4x4 WVPMatrix;"
"};"
""
"VS_OUTPUT Main(float4 Position : POSITION)"
"{"
"	VS_OUTPUT Output;"
"   "
"   Position.w = 1.0f;"
"	Output.Position = mul(Position, WVPMatrix);"
"	Output.WorldPosition = Position.xyz;"
"	return Output;"
"}";

const char* PLOT3D_PS_HLSL =
"struct VS_OUTPUT"
"{"
"	float4 Position : SV_POSITION;"
"	float3 WorldPosition : TEXCOORD;"
"};"
"cbuffer PER_PLOT : register(b0)"
"{"
"	float4 SurfaceColor;"
"};"
""
"float4 Main(VS_OUTPUT Input) : SV_TARGET"
"{"
"	"
"	return float4(  smoothstep( float2(-3, -3), float2(3, 3), Input.WorldPosition.xy), 0.5f, 1.0f );"
"	"
"}";

void Plot3DRenderer::Initialize(RenderSystemInterface* RenderSystemInterfacePtr, const Plot3DRenderData& RenderData, Plot3DRenderState& OutRenderState)
{
	OutRenderState.pVertexShader = RenderSystemInterfacePtr->CreateVertexShader(PLOT3D_VS_HLSL, strlen(PLOT3D_VS_HLSL));
	
	F32 OriginX = (RenderData.XMax + RenderData.XMin) / 2.0f;
	F32 OriginDistX = fabsf(RenderData.XMax - OriginX);

	F32 OriginY = (RenderData.YMax + RenderData.YMin) / 2.0f;
	F32 OriginDistY = fabsf(RenderData.YMax - OriginY);

	F32 OriginZ = (RenderData.ZMax + RenderData.ZMin) / 2.0f;
	F32 OriginDistZ = fabsf(RenderData.ZMax - OriginZ);

	Math::Matrix4x4 WorldMatrix = Math::Scale(1.0f / OriginDistX, 1.0f / OriginDistY, 1.0f / OriginDistZ) * Math::Translation(0.0f, 0.0f, 0.0f);
	Math::Matrix4x4 ViewMatrix = Math::LookAtMatrixLH(Math::Vector3{ 2.0f, -2.0f, 3.0f }, Math::Vector3{ 0.0f, 0.0f, 0.0f }, Math::Vector3{ 0.0f, 0.0f, 1.0f });
	Math::Matrix4x4 ProjectionMatrix = Math::PerspectiveFovMatrixLH(80.0f, (F32)(OutRenderState.pRenderTarget->Width) / (F32)(OutRenderState.pRenderTarget->Height), 0.0f, 1024.0f);

	struct VSUniformBufferData
	{
		Math::Matrix4x4 WVPMatrix;

	} VSUniformBufferData;

	VSUniformBufferData.WVPMatrix = Math::Transpose(WorldMatrix * ViewMatrix * ProjectionMatrix);

	OutRenderState.pVSUniformBuffer = RenderSystemInterfacePtr->CreateUniformBuffer(sizeof(VSUniformBufferData), EResourceUsage::STATIC, &VSUniformBufferData);


	OutRenderState.pPixelShader = RenderSystemInterfacePtr->CreatePixelShader(PLOT3D_PS_HLSL, strlen(PLOT3D_PS_HLSL));

	struct PSUniformBufferData
	{
		Math::ColorRGBA SurfaceColor;

	} PSUniformBufferData;

	PSUniformBufferData.SurfaceColor = Math::ColorRGBA{ 0.0f, 0.0f, 1.0f, 1.0f };

	OutRenderState.pPSUniformBuffer = RenderSystemInterfacePtr->CreateUniformBuffer(sizeof(PSUniformBufferData), EResourceUsage::STATIC, &PSUniformBufferData);

	VertexElement GraphVertexElement;
	GraphVertexElement.SemanticName = "POSITION";
	GraphVertexElement.Format = EGraphicsDataFormat::RGB_F32_F32_F32;
	GraphVertexElement.SlotIdx = 0;
	GraphVertexElement.Offset = 0;

	OutRenderState.pVertexDeclaration = RenderSystemInterfacePtr->CreateVertexDeclaration(&GraphVertexElement, 1, OutRenderState.pVertexShader);

	F32 cube[] = {
		// Front face
		-1.0f, -1.0f, 1.0f,
		1.0f, -1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,
		-1.0f, 1.0f, 1.0f,

		// Back face
		-1.0f, -1.0f, -1.0f,
		-1.0f, 1.0f, -1.0f,
		1.0f, 1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,

		// Top face
		-1.0f, 1.0f, -1.0f,
		-1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, -1.0f,

		// Bottom face
		-1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, 1.0f,
		-1.0f, -1.0f, 1.0f,

		// Right face
		1.0f, -1.0f, -1.0f,
		1.0f, 1.0f, -1.0f,
		1.0f, 1.0f, 1.0f,
		1.0f, -1.0f, 1.0f,

		// Left face
		-1.0f, -1.0f, -1.0f,
		-1.0f, -1.0f, 1.0f,
		-1.0f, 1.0f, 1.0f,
		-1.0f, 1.0f, -1.0f
	 };


	F32 pyramid[] = 
	{
		0.0f, 1.0f, 0.0f,
		-1.0f, -1.0f, 1.0f,
		1.0f, -1.0f, 1.0f,

		0.0f, 1.0f, 0.0f,
		-1.0f, -1.0f, 1.0f,
		0.0f, -1.0f, -1.0f,

		0.0f, 1.0f, 0.0f,
		0.0f, -1.0f, -1.0f,
		1.0f, -1.0f, 1.0f,

		-1.0f, -1.0f, 1.0f,
		0.0f, -1.0f, -1.0f,
		1.0f, -1.0f, 1.0f
	};





	OutRenderState.pVertexBuffer = RenderSystemInterfacePtr->CreateVertexBuffer(RenderData.GraphVertexCount * sizeof(Math::Vector3), EResourceUsage::STATIC, &(RenderData.pGraphVertexArray->operator[](0)));
	OutRenderState.pVertexBuffer->VertexCount = RenderData.GraphVertexCount;

	//OutRenderState.pVertexBuffer = RenderSystemInterfacePtr->CreateVertexBuffer(sizeof(F32) * 36, EResourceUsage::STATIC, pyramid);
	//OutRenderState.pVertexBuffer->VertexCount = 12;

	OutRenderState.pRasterizerState = RenderSystemInterfacePtr->CreateRasterizerState(ERasterizerCullMode::CULL_NONE, ERasterizerFillMode::WIREFRAME, false, false, false);
	OutRenderState.pBlendState = nullptr;
	OutRenderState.pDepthStencilState = RenderSystemInterfacePtr->CreateDepthStencilState(true, EComparisonFunction::CF_LESS_EQUAL);
	OutRenderState.pDepthStencilTarget = RenderSystemInterfacePtr->CreateDepthStencilTarget(OutRenderState.pRenderTarget->Width, OutRenderState.pRenderTarget->Height, EGraphicsDataFormat::DS_F24_F8);
}

void Plot3DRenderer::Render(RenderSystemInterface* RenderSystemInterfacePtr, const Plot3DRenderState& RenderState)
{
	RenderSystemInterfacePtr->ClearRenderTarget(RenderState.pRenderTarget, Math::ColorRGBA{ 0.0f, 0.0f, 0.0f, 1.0f });
	//RenderSystemInterfacePtr->ClearDepthStencilTarget(RenderState.pDepthStencilTarget, 1.0f, 0);

	RenderSystemInterfacePtr->SetVertexDeclaration(RenderState.pVertexDeclaration);
	RenderSystemInterfacePtr->SetVertexBuffer(RenderState.pVertexBuffer, 0, sizeof(Math::Vector3), 0);
	RenderSystemInterfacePtr->SetVertexShader(RenderState.pVertexShader);
	RenderSystemInterfacePtr->SetShaderUniformBuffer(RenderState.pVertexShader, 0, RenderState.pVSUniformBuffer);
	RenderSystemInterfacePtr->SetPixelShader(RenderState.pPixelShader);
	RenderSystemInterfacePtr->SetShaderUniformBuffer(RenderState.pPixelShader, 0, RenderState.pPSUniformBuffer);
	RenderSystemInterfacePtr->SetRasterizerState(RenderState.pRasterizerState);
	//RenderSystemInterfacePtr->SetDepthStencilState(RenderState.pDepthStencilState);
	// RenderSystemInterfacePtr->SetBlendState(RenderState.pBlendState, 0xFFFFFFFF);
	RenderSystemInterfacePtr->SetRenderTarget(RenderState.pRenderTarget, /*RenderState.pDepthStencilTarget*/nullptr);
	RenderSystemInterfacePtr->Draw(EPrimitiveType::POINT_LIST, RenderState.pVertexBuffer->VertexCount, 0);
}